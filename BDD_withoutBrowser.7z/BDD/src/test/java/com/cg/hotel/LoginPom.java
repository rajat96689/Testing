package com.cg.hotel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPom {
	
	WebDriver driver;
	

	@FindBy(how=How.NAME,name="userName")
	WebElement username;
	
	@FindBy(how=How.NAME,name="userPwd")
	WebElement password;
	
	@FindBy(how = How.CSS, using = ".btn")
	WebElement button;

	public boolean isAt(String title) {
		System.out.println("login page title is :: "+ driver.getTitle());
		if(driver.getTitle().equals(title))
			return true;
		return false;
	}
	
	public LoginPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);;
	}

	public String getPassword() {
		return password.getText();
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);;
	}

	public String getButton() {
		return button.getText();
	}

	public void setButton() {
		button.click();
		
	}
	
}
