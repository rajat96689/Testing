package com.cg.hotel;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" }, features="D:\\Practice\\RGUPTA\\BDD\\src\\test\\resources\\hotelbooking\\hotelbooking.feature")
public class RunCucumberTest {


}
