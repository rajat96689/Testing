package com.cg.hotel;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Stepdef {
	private WebDriver driver;
	private LoginPom log;
	private hotelPom hlog;
	
	@Before
	public void setUp() {
		String projectLocation=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\login.html");
		log=new LoginPom(driver);
		hlog=new hotelPom(driver);
	}
		
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(log.isAt("Login Hotel Booking")); 

	}

	@Then("^verification of heading$")
	public void verification_of_heading() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  // xpath="//*[@id=\"mainCnt\"]/div/div[1]/h1;"
		
		WebElement heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
		Assert.assertEquals("Hotel Booking Application", heading.getText());
	}

	@When("^user enter the username'(.*?)' and password'(.*?)'$")
	public void user_enter_the_username_capgemini_and_password_capg1234(String username, String password) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 System.out.println(username);
	 System.out.println(password);
	 log.setUsername(username);
	 log.setPassword(password);
	 
	}

	@Then("^verification and navigate to another page$")
	public void verification_and_navigate_to_another_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  log.setButton();
	  //driver.switchTo().alert().accept();
	//  Thread.sleep(1000);
	//  driver.close();
	}


	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		hlog.isAtHotel("Hotel Booking");
		//Assert.assertTrue(hlog.isAtHotel("Hotel Booking")); 
	}

	@Then("^verification of title$")
	public void verification_of_title() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  WebElement hoteltitle=driver.findElement(By.xpath("/html/head/title"));
	 // Assert.assertEquals("Hotel Booking", hoteltitle.getText());
		hlog.isSameTitle("Hotel Booking");
	}

	@When("^user enter all valid personal entry$")
	public void user_enter_all_valid_personal_entry() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
		 hlog.setFirstName("Rajat");
		 hlog.setLastName("Gupta");
		 Thread.sleep(1000);
		 hlog.setEmail("abc@gmail.com");
		 hlog.setMobile("7408303225");
		 Thread.sleep(1000);
		 hlog.setAddress("capgemini Talwade pune");
		 Thread.sleep(1000);
		 hlog.setCity("Pune");
		 hlog.setState("Maharashtra");
		 hlog.setNoOfGuest("5");
		 Thread.sleep(1000);
		 hlog.setCardHolderName("Shubh");
		 hlog.setDebitCardNumber("1223342424245");
		 hlog.setCvv("344");
		 hlog.setExpirationMonth("04");
		 hlog.setExpirationYear("2019");
		 Thread.sleep(3000);
		System.out.println("***********All Valid data Succesfully Submit***********");
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		hlog.setConfirmBooking();
		
		
	}

	@When("^user enter invalid personal entry$")
	public void user_enter_invalid_personal_entry() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
		 hlog.setFirstName("Rajat");
		 hlog.setLastName("");
		 Thread.sleep(1000);
		 hlog.setEmail("");
		 hlog.setMobile("7408225");
		 Thread.sleep(1000);
		 hlog.setAddress("capgemini Talwade pune");
		 Thread.sleep(1000);
		 hlog.setCity("Pune");
		 hlog.setState("Maharashtra");
		 hlog.setNoOfGuest("5");
		 Thread.sleep(1000);
		 hlog.setCardHolderName("Shubh");
		 hlog.setDebitCardNumber("1223342424245");
		 hlog.setCvv("344");
		 hlog.setExpirationMonth("04");
		 hlog.setExpirationYear("2020");
		 hlog.setConfirmBooking();
		 Alert prompt=driver.switchTo().alert();
		 String text=prompt.getText();
		 System.out.println(text);
		 prompt.accept();
		 Thread.sleep(3000);
	}

	@When("^user enter all valid payment entry$")
	public void user_enter_all_valid_payment_entry() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
		 hlog.setFirstName("Rajat");
		 hlog.setLastName("Gupta");
		 Thread.sleep(1000);
		 hlog.setEmail("abc@gmail.com");
		 hlog.setMobile("7408303225");
		 Thread.sleep(1000);
		 hlog.setAddress("capgemini Talwade pune");
		 Thread.sleep(1000);
		 hlog.setCity("Pune");
		 hlog.setState("Maharashtra");
		 hlog.setNoOfGuest("5");
		 Thread.sleep(1000);
		 hlog.setCardHolderName("Shubh");
		 hlog.setDebitCardNumber("1223342424245");
		 hlog.setCvv("344");
		 hlog.setExpirationMonth("04");
		 hlog.setExpirationYear("2019");
		 Thread.sleep(3000);
		 System.out.println("***********All Valid Payment Entry Succesfully Submit***********");
	}

	@When("^user enter invalid payment entry$")
	public void user_enter_invalid_payment_entry() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
		 hlog.setFirstName("Rajat");
		 hlog.setLastName("Gupta");
		 Thread.sleep(1000);
		 hlog.setEmail("abc@gmail.com");
		 hlog.setMobile("7408303225");
		 Thread.sleep(1000);
		 hlog.setAddress("capgemini Talwade pune");
		 Thread.sleep(1000);
		 hlog.setCity("Pune");
		 hlog.setState("Maharashtra");
		 hlog.setNoOfGuest("5");
		 Thread.sleep(1000);
		 hlog.setCardHolderName("Shubh");
		 hlog.setDebitCardNumber("");
		 hlog.setCvv("344");
		 hlog.setExpirationMonth("");
		 hlog.setExpirationYear("2019");
		 hlog.setConfirmBooking();
		 Alert prompt=driver.switchTo().alert();
		 String text=prompt.getText();
		 System.out.println(text);
		 prompt.accept();
		 Thread.sleep(3000);
		
		
		
	}



	

	@After
	public void tierDown() throws InterruptedException {
		Thread.sleep(2000);
		driver.quit();
	}
	
	
	
	
	
	
}
