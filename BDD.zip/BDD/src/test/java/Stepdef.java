import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Stepdef {
	private WebDriver driver;
	private LoginPom log;
	
	
	@Before
	public void setUp() {
		String projectLocation=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("E:\\RGUPTA90\\BDD\\src\\main\\webapp\\login.html");
		log=new LoginPom(driver);
		
	}
	
	
	@After
	public void tierDown() {
		
	}
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(log.isAt("Login Hotel Booking")); 

	}

	@Then("^verification of heading$")
	public void verification_of_heading() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  // xpath="//*[@id=\"mainCnt\"]/div/div[1]/h1;"
		
		WebElement heading=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
		Assert.assertEquals("Hotel Booking Application", heading.getText());
	}

	@When("^user enter the username'(.*?)' and password'(.*?)'$")
	public void user_enter_the_username_capgemini_and_password_capg1234(String username, String password) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	 System.out.println(username);
	 System.out.println(password);
	 log.setUsername(username);
	 log.setPassword(password);
	 
	}

	@Then("^verification and navigate to another page$")
	public void verification_and_navigate_to_another_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  log.setButton();
	}
	

	/*
	 * @Then("^accept the alert_box$") public void accept_the_alert_box() throws
	 * Exception { // Write code here that turns the phrase above into concrete
	 * actions String alertMessage = driver.switchTo().alert().getText();
	 * //Thread.sleep(1000); //driver.switchTo().alert().accept();
	 * System.out.println("******" + alertMessage); }
	 */

}
