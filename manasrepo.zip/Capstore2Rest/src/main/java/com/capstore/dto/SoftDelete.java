package com.capstore.dto;

public enum SoftDelete {
	Activated, Deactivated
}
