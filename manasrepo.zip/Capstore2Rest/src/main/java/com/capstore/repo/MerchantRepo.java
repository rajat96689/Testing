package com.capstore.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.dto.Admin;
import com.capstore.dto.Customer;
import com.capstore.dto.Merchant;
import com.capstore.dto.Product;


public interface MerchantRepo/* extends JpaRepository<Merchant, Integer> */{
 public List<Merchant> findAll();
 public Merchant findOne(int id);
 public List<Customer> findAllCustomer();
 public Customer findCustomer(int id);
 public Admin findAdmin(int id);
 public Product findPro(int id);
 

}
