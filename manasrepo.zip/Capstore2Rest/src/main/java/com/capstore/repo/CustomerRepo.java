package com.capstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.dto.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {

}
