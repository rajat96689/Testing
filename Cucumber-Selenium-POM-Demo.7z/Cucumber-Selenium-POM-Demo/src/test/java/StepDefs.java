import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

	@Given("^there is a toothpaste on brush$")
	public void there_is_a_toothpaste_on_brush() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//		TODO	CREATE A WEBDRIVER HERE
//		TODO NAVIGATING TO THE PAGE
	    throw new PendingException();
	}

	@Given("^the mouth is open$")
	public void the_mouth_is_open() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the back teeth are brushed$")
	public void the_back_teeth_are_brushed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
//		TODO:	WRITE A SELENIUM SCRIPT TO SIMULATE USER ACTIONS
	    throw new PendingException();
	}

	@When("^the front teeth are brushed$")
	public void the_front_teeth_are_brushed() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the tooth looks clean$")
	public void the_tooth_looks_clean() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//		TODO: 	ASSERTING WHETHER THOSE ACTIONS WERE SUCCESSFUL OR NOT
	    throw new PendingException();
	}

	@Then("^the mouth feels fresh$")
	public void the_mouth_feels_fresh() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the braces are not damaged$")
	public void the_braces_are_not_damaged() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
