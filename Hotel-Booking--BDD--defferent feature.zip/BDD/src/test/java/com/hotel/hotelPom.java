package com.hotel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class hotelPom {
	
	//constructor  
	public hotelPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		}

	//hotel title
	public boolean isAtHotel(String title) {
		if(driver.getTitle().equals(title))
			return true;
		return false;
	}

	 WebDriver driver;
	 @FindBy(how=How.NAME,name="txtFN")
	 WebElement firstName;
	 @FindBy(how=How.NAME,name="txtLN")
	 WebElement lastName;
	 @FindBy(how=How.NAME,name="Email")
	 WebElement email;
	 @FindBy(how=How.NAME,name="Phone")
	 WebElement mobile;
	 @FindBy(xpath = "/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	 WebElement address;
	 @FindBy(how=How.NAME,name="city")
	 WebElement city;
	 @FindBy(how=How.NAME,name="state")
	 WebElement state;
	 @FindBy(how=How.NAME,name="persons")
	 WebElement noOfGuest;
	 @FindBy(how=How.ID,id="txtCardholderName")
	 WebElement cardHolderName;
	 @FindBy(how=How.NAME,name="debit")
	 WebElement debitCardNumber;
	 @FindBy(how=How.NAME,name="cvv")
	 WebElement cvv;
	 @FindBy(how=How.NAME,name="month")
	 WebElement expirationMonth;
	 @FindBy(how=How.NAME,name="year")
	 WebElement expirationYear;
	 @FindBy(how=How.CSS,using=".btn")
	 WebElement confirmBooking;
	//getter and setter 
	 public WebElement getFirstName() {
		 return firstName;
		 }

		 public void setFirstName(String first) {
		 this.firstName.sendKeys(first);
		 }

		 public WebElement getLastName() {
		 return lastName;
		 }

		 public void setLastName(String last) {
		 this.lastName.sendKeys(last);
		 }

		 public WebElement getEmail() {
		 return email;
		 }

		 public void setEmail(String email) {
		 this.email.sendKeys(email);
		 }

		 public WebElement getMobile() {
		 return mobile;
		 }

		 public void setMobile(String mobile) {
		 this.mobile.sendKeys(mobile);
		 }

		 public WebElement getAddress() {
		 return address;
		 }

		 public void setAddress(String address) {
		 this.address.sendKeys(address);
		 }

		 public WebElement getCity() {
		 return city;
		 }

		 public void setCity(String city) {
		 this.city.sendKeys(city);
		 }

		 public WebElement getState() {
		 return state;
		 }

		 public void setState(String state) {
		 this.state.sendKeys(state);
		 }

		 public WebElement getNoOfGuest() {
		 return noOfGuest;
		 }

		 public void setNoOfGuest(String noOfGuest) {
		 this.noOfGuest.sendKeys(noOfGuest);
		 }

		 public WebElement getCardHolderName() {
		 return cardHolderName;
		 }

		 public void setCardHolderName(String cardHolderName) {
		 this.cardHolderName.sendKeys(cardHolderName);
		 }

		 public WebElement getDebitCardNumber() {
		 return debitCardNumber;
		 }

		 public void setDebitCardNumber(String debitCardNumber) {
		 this.debitCardNumber.sendKeys(debitCardNumber);
		 }

		 public WebElement getCvv() {
		 return cvv;
		 }

		 public void setCvv(String cvv) {
		 this.cvv.sendKeys(cvv);
		 }

		 public WebElement getExpirationMonth() {
		 return expirationMonth;
		 }

		 public void setExpirationMonth(String expirationMonth) {
		 this.expirationMonth.sendKeys(expirationMonth);
		 }

		 public WebElement getExpirationYear() {
		 return expirationYear;
		 }

		 public void setExpirationYear(String expirationYear) {
		 this.expirationYear.sendKeys(expirationYear);
		 }

		 public WebElement getConfirmBooking() {
		 return confirmBooking;
		 }

		 public void setConfirmBooking() {
		 this.confirmBooking.click();
		 }
	
}
