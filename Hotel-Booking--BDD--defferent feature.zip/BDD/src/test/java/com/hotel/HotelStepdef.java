package com.hotel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStepdef {
	private WebDriver driver;
	private hotelPom hlog;
	@Before
	public void setUp() {
		String projectLocation=System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
		hlog=new hotelPom(driver);
		
	}
	
	@After
	public void tearDown() {
		
	}


@Given("^user is on hotel booking page$")
public void user_is_on_hotel_booking_page() throws Exception {
    // Write code here that turns the phrase above into concrete actions

}

@Then("^verification of title$")
public void verification_of_title() throws Exception {
    // Write code here that turns the phrase above into concrete actions
    
}

@When("^user enter all valid personal entry$")
public void user_enter_all_valid_personal_entry() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\hotelbooking.html");
	 hlog.setFirstName("Rajat");
	 hlog.setLastName("Gupta");
	 Thread.sleep(1000);
	 hlog.setEmail("abc@gmail.com");
	 hlog.setMobile("7408303225");
	 Thread.sleep(1000);
	 hlog.setAddress("capgemini Talwade pune");
	 Thread.sleep(1000);
	 hlog.setCity("Pune");
	 hlog.setState("Maharashtra");
	 hlog.setNoOfGuest("5");
	 Thread.sleep(1000);
	 hlog.setCardHolderName("Shubh");
	 hlog.setDebitCardNumber("1223342424245");
	 hlog.setCvv("344");
	 hlog.setExpirationMonth("04");
	 hlog.setExpirationYear("2019");
	 Thread.sleep(3000);
	 /*driver.navigate().to("D:\\Practice\\RGUPTA\\BDD\\src\\main\\webapp\\success.html");*/
}

@Then("^navigate to next page$")
public void navigate_to_next_page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	hlog.setConfirmBooking();
	
	
}

@When("^user enter invalid personal entry$")
public void user_enter_invalid_personal_entry() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   
}

@When("^user enter all valid payment entry$")
public void user_enter_all_valid_payment_entry() throws Exception {
    // Write code here that turns the phrase above into concrete actions
 
}

@When("^user enter invalid payment entry$")
public void user_enter_invalid_payment_entry() throws Exception {
    // Write code here that turns the phrase above into concrete actions
   
}



	

	
}
